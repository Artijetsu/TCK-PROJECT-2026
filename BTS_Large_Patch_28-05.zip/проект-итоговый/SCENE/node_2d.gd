extends Node2D

const PLAYER_A := "res://ПЕРСОНАЖИ/character_body_2d.tscn"
const PLAYER_B := "res://ПЕРСОНАЖИ/character_body1_2d.tscn"

const PLAYER_NODE_NAME := "CharacterBody2D"
const PLAYER_TEMPLATE_B_NAME := "CharacterBody2D2"
const EMBEDDED_CAMERA_NAME := "Camera2D"
const SPAWN_POS_A := Vector2(1195, 36)
const SPAWN_POS_B := Vector2(1388, 34)

func _ready() -> void:
	var chosen_path := _get_selected_character_path()
	var root := get_parent()
	if root == null:
		root = self

	var p1: Node2D = root.get_node_or_null(PLAYER_NODE_NAME) as Node2D
	var p2: Node2D = root.get_node_or_null(PLAYER_TEMPLATE_B_NAME) as Node2D

	var spawn_position := _get_spawn_position(chosen_path, p1, p2)

	if p1 != null:
		p1.name = "deleted_p1"
		p1.queue_free()
	if p2 != null:
		p2.name = "deleted_p2"
		p2.queue_free()

	var player := _instantiate_player(chosen_path)
	if player == null:
		return

	player.name = PLAYER_NODE_NAME
	player.position = spawn_position
	add_child(player)

	var follow_cam = get_node_or_null("FollowCamera")
	if follow_cam != null and follow_cam.has_method("_set_target"):
		follow_cam._set_target(player)

func _get_selected_character_path() -> String:
	var chosen_path := PLAYER_A
	if Global and "selected_character_path" in Global:
		var maybe_path := str(Global.selected_character_path)
		if maybe_path != "":
			chosen_path = maybe_path
	return chosen_path

func _get_spawn_position(chosen_path: String, p1: Node2D, p2: Node2D) -> Vector2:
	if chosen_path == PLAYER_A and p1 != null:
		return p1.position
	if chosen_path == PLAYER_B and p2 != null:
		return p2.position
	if p1 != null:
		return p1.position
	if p2 != null:
		return p2.position
	if chosen_path == PLAYER_B:
		return SPAWN_POS_B
	return SPAWN_POS_A

func _instantiate_player(scene_path: String) -> Node2D:
	if not ResourceLoader.exists(scene_path):
		return null
	var packed := load(scene_path) as PackedScene
	if packed == null:
		return null
	return packed.instantiate() as Node2D

func _remove_embedded_camera(player: Node2D) -> void:
	var embedded_camera: Camera2D = player.get_node_or_null(EMBEDDED_CAMERA_NAME) as Camera2D
	if embedded_camera != null:
		embedded_camera.free()
