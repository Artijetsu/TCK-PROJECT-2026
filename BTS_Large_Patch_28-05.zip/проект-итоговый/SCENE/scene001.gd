extends Node2D

# ==================================================
# РЕСУРСЫ
# ==================================================



# Имя NPC.
@export var npc_name: String = "NPC"

# Реплики NPC.
@export var dialogues: Array[String] = []

# Заполняем данные NPC из другого скрипта.
func setup_npc_data(new_name: String, new_dialogues: Array[String]) -> void:
	npc_name = new_name
	dialogues = new_dialogues.duplicate()

# Скрипт NPC для зоны взаимодействия.
const NPC_SCRIPT_PATH := "res://SCRIPTS/npc.gd"

# Пути к сценам персонажей.
const CHAR_SUPERMAN := "res://ПЕРСОНАЖИ/character_body_2d.tscn"
const CHAR_SMARTMAN := "res://ПЕРСОНАЖИ/character_body1_2d.tscn"

# ==================================================
# ИМЕНА УЗЛОВ И БАЗОВЫЕ НАСТРОЙКИ
# ==================================================

# Имя узла игрока на сцене.
const PLAYER_NODE_NAME := "CharacterBody2D"

# Имя узла NPC на сцене.
const NPC_NODE_NAME := "NPC"

# Имя зоны взаимодействия NPC.
const NPC_INTERACTION_AREA_NAME := "InteractionArea"

# Имя лейбла подсказки.
const HINT_LABEL_NAME := "HintLabel"

# Путь к камере у персонажей.
const CAMERA_NODE_NAME := "Camera2D"

# Путь к коллизии персонажа.
const COLLISION_SHAPE_NODE_NAME := "CollisionShape2D"

# Стандартная позиция игрока, если его нет на сцене.
const DEFAULT_PLAYER_POSITION := Vector2(100, 100)

# Стандартная позиция NPC.
const DEFAULT_NPC_POSITION := Vector2(99, 157)

# Тот же масштаб, что у игрока (без уменьшения — персонажи одного размера).
const NPC_SCALE := Vector2(1.0, 1.0)

# Коллизия совпадает с визуалом персонажа.
const NPC_COLLISION_SCALE := Vector2(1.0, 1.0)

# Радиус зоны взаимодействия (подсказка и клавиша E).
const NPC_INTERACTION_RADIUS := 175.0

const NPC_HINT_SCALE := Vector2(1.0, 1.0)

# Позиция над головой (локально к зоне взаимодействия).
const NPC_HINT_POSITION := Vector2(-120, -220)

const SMART_WATCH_SCENE := preload("res://SCENE/smart_watch_ui.tscn")

# ==================================================
# ИНИЦИАЛИЗАЦИЯ СЦЕНЫ
# ==================================================

# Подготавливаем первый уровень при загрузке.
func _ready() -> void:
	print("Сцена 001 открыта")


	add_smart_watch()
	_setup_character()
	_setup_npc()
	_ensure_wall_collisions()

# Сцена часов должна существовать в дереве,
# иначе _ready() и _input() у smart_watch.gd никогда не сработают.
func add_smart_watch() -> void:
	var existing_watch := get_node_or_null("UI/SmartWatchUI")
	if existing_watch != null:
		return

	var smart_watch_instance = SMART_WATCH_SCENE.instantiate()
	var ui_layer := get_node_or_null("UI")
	if ui_layer != null:
		ui_layer.add_child(smart_watch_instance)
	else:
		add_child(smart_watch_instance)



# ==================================================
# НАСТРОЙКА ИГРОКА
# ==================================================

# Подготавливаем игрока в зависимости от выбора в Global.
func _setup_character() -> void:
	var selected_path := get_selected_character_path()

	print("Выбранный персонаж: ", selected_path)

	var current_character = get_node_or_null(PLAYER_NODE_NAME)

	if current_character != null:
		replace_character_if_needed(current_character, selected_path)
	else:
		create_character_if_missing(selected_path)

# Возвращает путь к выбранному персонажу.
func get_selected_character_path() -> String:
	var selected_path := CHAR_SUPERMAN

	if Global and "selected_character_path" in Global:
		selected_path = Global.selected_character_path

	return selected_path

# Заменяет текущего игрока, если выбран другой персонаж.
func replace_character_if_needed(current_character: Node, selected_path: String) -> void:
	if current_character.scene_file_path == selected_path:
		print("Персонаж уже на месте")
		return

	print("Заменяем персонажа...")

	var character_position: Vector2 = current_character.position
	var new_character = instantiate_scene_safe(selected_path)

	if new_character == null:
		printerr("Файл персонажа не найден: ", selected_path)
		return

	new_character.position = character_position
	new_character.name = PLAYER_NODE_NAME

	current_character.queue_free()
	add_child(new_character)

	activate_character_camera(new_character)
	disable_scene_camera()

# Создаёт игрока, если его нет на сцене.
func create_character_if_missing(selected_path: String) -> void:
	var new_character = instantiate_scene_safe(selected_path)

	if new_character == null:
		return

	new_character.position = DEFAULT_PLAYER_POSITION
	new_character.name = PLAYER_NODE_NAME
	add_child(new_character)

# Включает камеру у нового персонажа.
func activate_character_camera(character: Node) -> void:
	var camera = character.get_node_or_null(CAMERA_NODE_NAME)

	if camera != null:
		camera.enabled = true
		camera.make_current()

# Отключает отдельную камеру сцены, если она есть.
func disable_scene_camera() -> void:
	var scene_camera = get_node_or_null(CAMERA_NODE_NAME)

	if scene_camera != null:
		scene_camera.enabled = false

# ==================================================
# НАСТРОЙКА NPC
# ==================================================

# Создаём NPC как второго персонажа.
func _setup_npc() -> void:
	var player_path := get_selected_character_path()
	var npc_data := get_npc_data(player_path)

	var current_npc = get_node_or_null(NPC_NODE_NAME)
	var npc_position := DEFAULT_NPC_POSITION

	if current_npc != null:
		npc_position = current_npc.position
		current_npc.queue_free()

	var npc_instance = instantiate_scene_safe(npc_data.path)
	if npc_instance == null:
		return

	prepare_npc_instance(npc_instance, npc_position)
	add_npc_interaction_area(npc_instance, npc_data.display_name)

	add_child(npc_instance)

# Возвращает путь и отображаемое имя NPC.
# Первый персонаж (character_body_2d) → на карте второй скин, имя Алена.
# Второй персонаж (character_body1_2d) → на карте первый скин, имя Дима.
func get_npc_data(player_path: String) -> Dictionary:
	var npc_path := CHAR_SMARTMAN
	var npc_name_display := "Алена"

	if player_path == CHAR_SMARTMAN:
		npc_path = CHAR_SUPERMAN
		npc_name_display = "Дима"

	return {
		"path": npc_path,
		"display_name": npc_name_display
	}

# Подготавливаем внешний вид и базовые свойства NPC.
func prepare_npc_instance(npc_instance: Node2D, npc_position: Vector2) -> void:
	npc_instance.name = NPC_NODE_NAME
	npc_instance.position = npc_position
	npc_instance.scale = NPC_SCALE
	npc_instance.z_index = 0

	# Только слой стен: иначе Area2D с mask=2 будет видеть тело NPC как «игрока».
	if npc_instance is CollisionObject2D:
		npc_instance.collision_layer = 1
		npc_instance.collision_mask = 1

	resize_npc_collision(npc_instance)
	remove_npc_player_script(npc_instance)
	remove_npc_camera(npc_instance)

# Уменьшаем коллизию NPC, чтобы в него не упираться.
func resize_npc_collision(npc_instance: Node) -> void:
	var collision_shape = npc_instance.get_node_or_null(COLLISION_SHAPE_NODE_NAME)

	if collision_shape != null:
		collision_shape.scale = NPC_COLLISION_SCALE

# Убираем у NPC скрипт игрока.
func remove_npc_player_script(npc_instance: Node) -> void:
	npc_instance.set_script(null)

# Удаляем камеру у NPC, если она есть.
func remove_npc_camera(npc_instance: Node) -> void:
	var camera = npc_instance.get_node_or_null(CAMERA_NODE_NAME)

	if camera != null:
		camera.queue_free()

# ==================================================
# ЗОНА ВЗАИМОДЕЙСТВИЯ NPC
# ==================================================

# Создаём и добавляем NPC зону взаимодействия.
func add_npc_interaction_area(npc_instance: Node, npc_name_display: String) -> void:
	var interaction_area = create_npc_interaction_area()
	apply_npc_script(interaction_area, npc_name_display)

	var interaction_collision = create_npc_interaction_collision()
	var hint_label = create_npc_hint_label()

	interaction_area.add_child(interaction_collision)
	interaction_area.add_child(hint_label)

	connect_npc_interaction_signals(interaction_area)
	npc_instance.add_child(interaction_area)

# Создаём Area2D для взаимодействия с NPC.
func create_npc_interaction_area() -> Area2D:
	var interaction_area = Area2D.new()

	interaction_area.name = NPC_INTERACTION_AREA_NAME
	interaction_area.collision_layer = 1
	# Слой 2: только игрок (collision_layer персонажей = 1 | 2), не тело NPC (только слой 1).
	interaction_area.collision_mask = 2
	interaction_area.monitoring = true
	interaction_area.monitorable = true

	return interaction_area

# Назначаем скрипт NPC и заполняем его параметры.
func apply_npc_script(interaction_area: Area2D, npc_name_display: String) -> void:
	var npc_script = load(NPC_SCRIPT_PATH)
	interaction_area.set_script(npc_script)

	interaction_area.npc_name = npc_name_display

	var lines: Array[String] = [
		"Привет! Я " + npc_name_display + ".",
		"Ты выбрал другого героя, но я тоже тут."
	]
	interaction_area.dialogue_lines = lines

# Создаём коллизию для зоны взаимодействия NPC.
func create_npc_interaction_collision() -> CollisionShape2D:
	var collision_shape = CollisionShape2D.new()
	var circle_shape = CircleShape2D.new()

	circle_shape.radius = NPC_INTERACTION_RADIUS
	collision_shape.shape = circle_shape

	return collision_shape

# Создаём подсказку над NPC.
func create_npc_hint_label() -> Label:
	var label = Label.new()

	label.name = HINT_LABEL_NAME
	label.text = "Нажмите Е"
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.scale = NPC_HINT_SCALE
	label.position = NPC_HINT_POSITION
	label.custom_minimum_size = Vector2(260, 40)
	label.visible = false
	label.z_index = 100

	label.add_theme_font_size_override("font_size", 72)

	return label

# Подключаем сигналы входа и выхода игрока для NPC.
func connect_npc_interaction_signals(interaction_area: Area2D) -> void:
	if interaction_area.has_method("_on_body_entered"):
		interaction_area.body_entered.connect(interaction_area._on_body_entered)

	if interaction_area.has_method("_on_body_exited"):
		interaction_area.body_exited.connect(interaction_area._on_body_exited)

# ==================================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ==================================================

# Безопасно загружает и создаёт экземпляр сцены по пути.
func instantiate_scene_safe(scene_path: String) -> Node:
	if not ResourceLoader.exists(scene_path):
		return null

	var packed_scene = load(scene_path)
	return packed_scene.instantiate()


# Невидимые стены по границам зоны камеры — нельзя выйти за пределы комнаты.
func _add_map_boundary_walls() -> void:
	const THICK := 80.0
	const LIMIT_LEFT := 3.0
	const LIMIT_TOP := -633.0
	const LIMIT_RIGHT := 1918.0
	const LIMIT_BOTTOM := 1277.0

	var width := LIMIT_RIGHT - LIMIT_LEFT
	var height := LIMIT_BOTTOM - LIMIT_TOP
	var cx := (LIMIT_LEFT + LIMIT_RIGHT) * 0.5
	var cy := (LIMIT_TOP + LIMIT_BOTTOM) * 0.5

	_add_boundary_segment("MapBoundaryLeft", Vector2(LIMIT_LEFT - THICK * 0.5, cy), Vector2(THICK, height + THICK * 2))
	_add_boundary_segment("MapBoundaryRight", Vector2(LIMIT_RIGHT + THICK * 0.5, cy), Vector2(THICK, height + THICK * 2))
	_add_boundary_segment("MapBoundaryTop", Vector2(cx, LIMIT_TOP - THICK * 0.5), Vector2(width + THICK * 2, THICK))
	_add_boundary_segment("MapBoundaryBottom", Vector2(cx, LIMIT_BOTTOM + THICK * 0.5), Vector2(width + THICK * 2, THICK))


func _add_boundary_segment(segment_name: String, pos: Vector2, size: Vector2) -> void:
	var body := StaticBody2D.new()
	body.name = segment_name
	body.collision_layer = 1
	body.collision_mask = 0
	body.position = pos

	var shape_node := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = size
	shape_node.shape = rect
	body.add_child(shape_node)
	add_child(body)


# Коллизия по каждой занятой клетке мебели — на кровать, стол и кресло нельзя наступать.
const FURNITURE_TILE_LAYERS: Array[String] = ["Bed", "Table", "Chair", "Computer", "Shelves", "Lamp"]


func _add_furniture_collision_from_tile_layers() -> void:
	for layer_name in FURNITURE_TILE_LAYERS:
		var layer := get_node_or_null(layer_name)
		if layer == null or not layer is TileMapLayer:
			push_warning("Слой мебели не найден или не TileMapLayer: ", layer_name)
			continue

		var tile_set: TileSet = layer.tile_set
		if tile_set == null:
			continue

		var tile_size := Vector2(tile_set.tile_size)
		var idx := 0

		for cell in layer.get_used_cells():
			var body := StaticBody2D.new()
			body.name = "%sCollider%d" % [layer_name, idx]
			idx += 1
			body.collision_layer = 1
			body.collision_mask = 0

			var shape_node := CollisionShape2D.new()
			var rect := RectangleShape2D.new()
			rect.size = tile_size
			shape_node.shape = rect
			body.add_child(shape_node)

			body.position = layer.map_to_local(cell) + tile_size * 0.5
			layer.add_child(body)


const WALL_TILE_LAYER_NAMES: Array[String] = ["Wall", "SecretWall", "SecretSideWall"]


func _ensure_wall_collisions() -> void:
	var layers := _collect_tile_layers_by_names(WALL_TILE_LAYER_NAMES)
	for layer in layers:
		_add_collision_for_tile_layer(layer)


func _collect_tile_layers_by_names(names: Array[String]) -> Array[TileMapLayer]:
	var result: Array[TileMapLayer] = []
	var stack: Array[Node] = [self]

	while not stack.is_empty():
		var node: Node = stack.pop_back()
		if node is TileMapLayer and names.has(node.name):
			result.append(node as TileMapLayer)

		for child in node.get_children():
			if child is Node:
				stack.append(child)

	return result


func _add_collision_for_tile_layer(layer: TileMapLayer) -> void:
	if layer == null:
		return

	var old_container := layer.get_node_or_null("_GeneratedColliders")
	if old_container != null:
		old_container.queue_free()

	var tile_set: TileSet = layer.tile_set
	if tile_set == null:
		return

	var tile_size := Vector2(tile_set.tile_size)
	if tile_size == Vector2.ZERO:
		return

	var container := Node2D.new()
	container.name = "_GeneratedColliders"
	layer.add_child(container)

	var idx := 0
	for cell in layer.get_used_cells():
		var body := StaticBody2D.new()
		body.name = "WallCollider%d" % idx
		idx += 1
		body.collision_layer = 1
		body.collision_mask = 0

		var shape_node := CollisionShape2D.new()
		var rect := RectangleShape2D.new()
		rect.size = tile_size
		shape_node.shape = rect
		body.add_child(shape_node)

		body.position = layer.map_to_local(cell) + tile_size * 0.5
		container.add_child(body)
