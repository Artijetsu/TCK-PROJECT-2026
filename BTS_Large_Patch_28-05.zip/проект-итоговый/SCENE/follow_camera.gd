extends Camera2D

@export var target_path: NodePath
@export var follow_speed: float = 8.0

var _target: Node2D = null

func _ready() -> void:
	top_level = true
	enabled = true
	make_current()
	position_smoothing_enabled = false
	set_process(true)
	call_deferred("_resolve_target")

func _process(delta: float) -> void:
	if not is_current():
		enabled = true
		make_current()
	if _target == null or not is_instance_valid(_target):
		_resolve_target()
		return
	var t: float = clampf(follow_speed * delta, 0.0, 1.0)
	global_position = global_position.lerp(_target.global_position, t)

func _set_target(new_target: Node2D) -> void:
	_target = new_target
	if _target != null:
		global_position = _target.global_position

func _resolve_target() -> void:
	var node: Node = get_node_or_null(target_path)
	var node2d: Node2D = node as Node2D
	if node2d != null:
		_target = node2d
		global_position = _target.global_position
	else:
		# Резервный поиск, если target_path сбился
		var p = get_parent()
		if p != null:
			var fallback = p.get_node_or_null("CharacterBody2D")
			if fallback is Node2D:
				_target = fallback
				global_position = _target.global_position
