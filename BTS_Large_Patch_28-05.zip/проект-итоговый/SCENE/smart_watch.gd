extends Control


# ==================================================
# РЕСУРСЫ
# ==================================================

# Сцена пользовательского соглашения.
const EULA_SCENE := preload("res://SCENE/eula_ui.tscn")

# Сцена телепортации.
const TELEPORT_SCENE_PATH := "res://SCENE/node_2d.tscn"
const TOGGLE_ACTION := "toggle_watch"


# ==================================================
# ССЫЛКИ НА ЭЛЕМЕНТЫ ИНТЕРФЕЙСА
# ==================================================

# Главная панель часов.
@onready var main_panel = $MainPanel

# Панель рандомайзера.
@onready var randomizer_panel = $RandomizerPanel

# Текстовое поле помощника.
@onready var helper_label = $MainPanel/DialogueBox/RichTextLabel

# Слоты с картинками в рандомайзере.
@onready var slot1 = $RandomizerPanel/Slots/Slot1/Image
@onready var slot2 = $RandomizerPanel/Slots/Slot2/Image
@onready var slot3 = $RandomizerPanel/Slots/Slot3/Image

# Кнопки рандомайзера.
@onready var spin_btn = $RandomizerPanel/SpinBtn
@onready var teleport_btn = $RandomizerPanel/TeleportBtn


# ==================================================
# ДАННЫЕ ПОМОЩНИКА
# ==================================================

# Реплики помощника в главной панели.
var helper_lines: Array[String] = [
	"Привет! Я твой умный помощник.",
	"Нажми 'Выбор вселенной', чтобы испытать удачу.",
	"Если выпадут три одинаковые картинки, ты сможешь переместиться!",
	"Не забывай проверять сундуки.",
	"Удачи в путешествиях!"
]

# Индекс текущей реплики помощника.
var current_line_index: int = 0
var _paused_by_watch: bool = false


# ==================================================
# ДАННЫЕ РАНДОМАЙЗЕРА
# ==================================================

# Счётчик попыток прокрутки.
var spin_attempts: int = 0

# Картинки для слотов.
var images = [
	preload("res://IMG/супермэн.webp"),
	preload("res://IMG/умный человек.webp"),
	preload("res://IMG/вселеная.webp")
]


# ==================================================
# ДИАГНОСТИКА ЖИЗНЕННОГО ЦИКЛА
# ==================================================

# Если это сообщение не появляется в Output,
# значит сцена часов вообще не входит в дерево.
func _enter_tree() -> void:
	print("[WATCH] _enter_tree | node=", name)


# ==================================================
# ИНИЦИАЛИЗАЦИЯ
# ==================================================

# Подготавливаем интерфейс часов при запуске сцены.
func _ready() -> void:
	# Часы должны продолжать работать даже при паузе.
	process_mode = Node.PROCESS_MODE_ALWAYS

	# Явно включаем обработку ввода.
	set_process_input(true)

	# Важно:
	# хотбар больше не создаётся внутри часов.
	# Если оставить его дочерним узлом часов, он будет скрываться вместе с оверлеем.
	_ensure_toggle_action()
	setup_initial_state()
	connect_watch_signals()

	print("[WATCH] _ready called | visible=", visible, " | paused=", get_tree().paused)

func _ensure_toggle_action() -> void:
	if not InputMap.has_action(TOGGLE_ACTION):
		InputMap.add_action(TOGGLE_ACTION)
	InputMap.action_erase_events(TOGGLE_ACTION)

	var ev_z := InputEventKey.new()
	ev_z.keycode = KEY_Z
	InputMap.action_add_event(TOGGLE_ACTION, ev_z)

	var ev_z_physical := InputEventKey.new()
	ev_z_physical.physical_keycode = KEY_Z
	InputMap.action_add_event(TOGGLE_ACTION, ev_z_physical)


func _try_toggle() -> void:
	if not Global.courier_dialogue_completed:
		print("[WATCH] blocked: not unlocked yet")
		return
	visible = not visible
	print("[WATCH] toggled | visible=", visible)


# Настраиваем интерфейс часов в стартовое состояние.
func setup_initial_state() -> void:
	visible = false
	main_panel.visible = true
	randomizer_panel.visible = false
	teleport_btn.disabled = true
	update_helper_text()


# Подключаем сигналы интерфейса часов.
func connect_watch_signals() -> void:
	if not visibility_changed.is_connected(_on_visibility_changed):
		visibility_changed.connect(_on_visibility_changed)


# ==================================================
# ПАУЗА И ВИДИМОСТЬ
# ==================================================

# Реагируем на открытие и закрытие часов.
func _on_visibility_changed() -> void:
	if visible:
		_paused_by_watch = true
		get_tree().paused = true
	elif _paused_by_watch:
		_paused_by_watch = false
		get_tree().paused = false
	Global.is_smart_watch_open = visible

	# Если часы открылись впервые, запускаем интро.
	if visible and not Global.smart_watch_intro_completed:
		start_intro_sequence()


# ==================================================
# ВСТУПИТЕЛЬНАЯ СЦЕНА ЧАСОВ
# ==================================================

# Запускаем полную цепочку интро.
func start_intro_sequence() -> void:
	Global.is_cutscene_playing = true
	main_panel.visible = false

	var dialogue_ui = get_dialogue_ui()
	if dialogue_ui == null:
		print("[WATCH] DialogueUI not found")
		return

	await play_intro_dialogues(dialogue_ui)
	await show_eula()
	await play_intro_finish_dialogue(dialogue_ui)
	await vanish_first_npc()
	await play_player_reaction(dialogue_ui)

	Global.smart_watch_intro_completed = true
	Global.is_cutscene_playing = false
	main_panel.visible = true


# Возвращаем UI диалога.
func get_dialogue_ui() -> Node:
	return get_tree().get_first_node_in_group("DialogueUI")


# Проигрываем первые две реплики часов.
func play_intro_dialogues(dialogue_ui: Node) -> void:
	var lines: Array[Dictionary] = [
		{
			"name": "Умные часы",
			"text": "Здравствуй, пользователь! Я твой компаньон в путешествиях между вселенными."
		},
		{
			"name": "Умные часы",
			"text": "Перед тем как мы начнем наше увлекательное путешествие, ты должен подписать пользовательское соглашение."
		}
	]

	dialogue_ui.start_dialogue(lines, null)
	await dialogue_ui.dialogue_ended


# Показываем окно пользовательского соглашения.
func show_eula() -> void:
	var eula_instance = EULA_SCENE.instantiate()
	get_parent().add_child(eula_instance)
	await eula_instance.agreement_signed


# Проигрываем реплику часов после принятия соглашения.
func play_intro_finish_dialogue(dialogue_ui: Node) -> void:
	var lines: Array[Dictionary] = [
		{
			"name": "Умные часы",
			"text": "Отлично, да начнется великое путешествие!"
		}
	]

	dialogue_ui.start_dialogue(lines, null)
	await dialogue_ui.dialogue_ended


# Исчезновение первого NPC.
func vanish_first_npc() -> void:
	var npcs = get_tree().get_nodes_in_group("NPC")

	if npcs.is_empty():
		return

	npcs[0].vanish()
	await get_tree().create_timer(1.0, true, false, true).timeout


# Реплика игрока после исчезновения NPC.
func play_player_reaction(dialogue_ui: Node) -> void:
	var lines: Array[Dictionary] = [
		{
			"name": "Игрок",
			"text": "Какого черта? Где он? Жестянка! Верни моего друга!"
		}
	]

	dialogue_ui.start_dialogue(lines, null)
	await dialogue_ui.dialogue_ended


# ==================================================
# ОБРАБОТКА ВВОДА
# ==================================================

# Открываем и закрываем часы по Z.
func _input(event: InputEvent) -> void:
	if not (event is InputEventKey):
		return

	var key_event: InputEventKey = event

	# Игнорируем отпускание клавиши и автоповтор.
	if not key_event.pressed or key_event.echo:
		return

	print(
		"[WATCH] key event | keycode=", key_event.keycode,
		" | physical=", key_event.physical_keycode,
		" | visible=", visible,
		" | paused=", get_tree().paused,
		" | cutscene=", Global.is_cutscene_playing,
		" | courier_done=", Global.courier_dialogue_completed
	)

	if event.is_action_pressed(TOGGLE_ACTION):
		_try_toggle()


# ==================================================
# ГЛАВНАЯ ПАНЕЛЬ
# ==================================================

# Закрываем часы.
func _on_close_pressed() -> void:
	visible = false


# Открываем панель выбора вселенной.
func _on_universe_select_pressed() -> void:
	show_randomizer_panel()


# Переходим к предыдущей фразе помощника.
func _on_prev_line_pressed() -> void:
	if current_line_index <= 0:
		return

	current_line_index -= 1
	update_helper_text()


# Переходим к следующей фразе помощника.
func _on_next_line_pressed() -> void:
	if current_line_index >= helper_lines.size() - 1:
		return

	current_line_index += 1
	update_helper_text()


# Обновляем текст помощника.
func update_helper_text() -> void:
	helper_label.text = helper_lines[current_line_index]


# ==================================================
# ПЕРЕКЛЮЧЕНИЕ ПАНЕЛЕЙ
# ==================================================

# Показываем главную панель.
func show_main_panel() -> void:
	main_panel.visible = true
	randomizer_panel.visible = false


# Показываем панель рандомайзера.
func show_randomizer_panel() -> void:
	main_panel.visible = false
	randomizer_panel.visible = true


# ==================================================
# ПАНЕЛЬ РАНДОМАЙЗЕРА
# ==================================================

# Возвращаемся из рандомайзера в главное меню часов.
func _on_back_pressed() -> void:
	show_main_panel()


# Нажатие на кнопку прокрутки.
func _on_spin_pressed() -> void:
	if not Global.spend_coins(1):
		show_main_panel()
		helper_label.text = "Недостаточно монет для запуска! Поищи их в мире."
		return

	lock_randomizer_buttons()
	await play_spin_animation()

	spin_attempts += 1

	var final_results = get_final_spin_results()
	apply_spin_results(final_results)
	unlock_spin_button()

	if is_jackpot(final_results):
		teleport_btn.disabled = false
		print("Джекпот! Перемещение разблокировано.")


# Блокируем кнопки во время вращения.
func lock_randomizer_buttons() -> void:
	spin_btn.disabled = true
	teleport_btn.disabled = true


# Разблокируем кнопку прокрутки после вращения.
func unlock_spin_button() -> void:
	spin_btn.disabled = false


# Проигрываем анимацию случайной прокрутки.
func play_spin_animation() -> void:
	for i in range(20):
		slot1.texture = images.pick_random()
		slot2.texture = images.pick_random()
		slot3.texture = images.pick_random()
		await get_tree().create_timer(0.1).timeout


# Получаем итоговые изображения после прокрутки.
func get_final_spin_results() -> Array:
	if spin_attempts >= 5:
		var guaranteed_image = images.pick_random()

		print("Гарантированный выигрыш! Попытка: ", spin_attempts)

		return [guaranteed_image, guaranteed_image, guaranteed_image]

	return [
		images.pick_random(),
		images.pick_random(),
		images.pick_random()
	]


# Устанавливаем итоговые картинки в слоты.
func apply_spin_results(results: Array) -> void:
	slot1.texture = results[0]
	slot2.texture = results[1]
	slot3.texture = results[2]


# Проверяем, совпали ли все три изображения.
func is_jackpot(results: Array) -> bool:
	return results[0] == results[1] and results[1] == results[2]


# ==================================================
# ТЕЛЕПОРТАЦИЯ
# ==================================================

# Выполняем телепортацию после победы.
func _on_teleport_pressed() -> void:
	print("Телепортация...")

	visible = false
	get_tree().paused = false
	Global.is_smart_watch_open = false

	get_tree().change_scene_to_file(TELEPORT_SCENE_PATH)
