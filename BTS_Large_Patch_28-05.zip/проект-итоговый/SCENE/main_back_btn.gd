extends Button

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

func _on_pressed():
	get_tree().paused = false
	get_tree().change_scene_to_file("res://SCENE/main_optimized.tscn")
