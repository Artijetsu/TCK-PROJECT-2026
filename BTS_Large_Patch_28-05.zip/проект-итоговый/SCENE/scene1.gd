extends Control

# Ссылки на кнопки
var btn_left: Button
var btn_right: Button
var _hovered_btn: Button = null

# Пути к изображениям
const IMG_SUPERMAN = "res://IMG/man.png"
const IMG_SMARTMAN = "res://IMG/woman.png"

# Пути к персонажам
const CHAR_SUPERMAN = "res://ПЕРСОНАЖИ/character_body_2d.tscn"
const CHAR_SMARTMAN = "res://ПЕРСОНАЖИ/character_body1_2d.tscn"

const GAME_SCENE_PATH = "res://SCENE/scene001.tscn"

const COLOR_NORMAL := Color(1.0, 1.0, 1.0, 1.0)
const COLOR_DIM := Color(0.6, 0.6, 0.6, 1.0)
const COLOR_HIGHLIGHT := Color(1.15, 1.15, 1.15, 1.0)

func _ready() -> void:
	# Получаем размер экрана
	var viewport_size = get_viewport_rect().size
	
	# Настройка левой кнопки
	btn_left = Button.new()
	# Текст можно убрать, так как есть картинка
	btn_left.text = "" 
	btn_left.name = "LeftButton"
	add_child(btn_left)
	setup_button_style(btn_left, IMG_SUPERMAN)
	
	# Настройка правой кнопки
	btn_right = Button.new()
	btn_right.text = ""
	btn_right.name = "RightButton"
	add_child(btn_right)
	setup_button_style(btn_right, IMG_SMARTMAN)
	
	# Подключаем сигналы с привязкой аргументов
	btn_left.pressed.connect(_on_left_button_pressed)
	btn_right.pressed.connect(_on_right_button_pressed)
	
	# Размеры
	btn_left.size = Vector2(viewport_size.x / 2, viewport_size.y)
	btn_right.size = Vector2(viewport_size.x / 2, viewport_size.y)
	
	# Начальные позиции (за пределами экрана)
	btn_left.position = Vector2(-btn_left.size.x, 0)
	btn_right.position = Vector2(viewport_size.x, 0)
	
	# Анимация выезда
	var tween = create_tween().set_parallel(true).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tween.tween_property(btn_left, "position:x", 0.0, 1.0)
	tween.tween_property(btn_right, "position:x", viewport_size.x / 2, 1.0)
	_apply_hover_visuals(null)

func setup_button_style(btn: Button, path: String) -> void:
	if ResourceLoader.exists(path):
		var texture: Texture2D = load(path)
		btn.flat = true
		btn.modulate = COLOR_NORMAL
		btn.mouse_entered.connect(_on_button_mouse_entered.bind(btn))
		btn.mouse_exited.connect(_on_button_mouse_exited.bind(btn))
		
		var img := TextureRect.new()
		img.name = "Image"
		img.texture = texture
		img.set_anchors_preset(Control.PRESET_FULL_RECT)
		img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		img.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		img.mouse_filter = Control.MOUSE_FILTER_IGNORE
		btn.add_child(img)

func _on_button_mouse_entered(btn: Button) -> void:
	_hovered_btn = btn
	_apply_hover_visuals(btn)

func _on_button_mouse_exited(btn: Button) -> void:
	if _hovered_btn == btn:
		_hovered_btn = null
	_apply_hover_visuals(_hovered_btn)

func _apply_hover_visuals(hovered: Button) -> void:
	if btn_left == null or btn_right == null:
		return

	if hovered == null:
		btn_left.modulate = COLOR_NORMAL
		btn_right.modulate = COLOR_NORMAL
		return

	if hovered == btn_left:
		btn_left.modulate = COLOR_HIGHLIGHT
		btn_right.modulate = COLOR_DIM
	elif hovered == btn_right:
		btn_right.modulate = COLOR_HIGHLIGHT
		btn_left.modulate = COLOR_DIM

func _on_left_button_pressed() -> void:
	_load_game(CHAR_SUPERMAN)

func _on_right_button_pressed() -> void:
	_load_game(CHAR_SMARTMAN)

func _load_game(char_path: String) -> void:
	Global.selected_character_path = char_path
	get_tree().change_scene_to_file(GAME_SCENE_PATH)
