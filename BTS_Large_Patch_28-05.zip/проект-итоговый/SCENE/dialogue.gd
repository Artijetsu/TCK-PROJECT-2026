extends Control
# Переменная, куда будем складывать весь диалог. Видна в редакторе, пока пустая
@export var dialogues: Array[Dictionary] = []
@export var type_speed: float = 14.0 # скорость печати (символов в секунду)
# Ссылка на картинку с портретом персонажа (TextureRect)
@onready var portrait: TextureRect = get_node_or_null("Portrait")
# Ссылка на текст с именем персонажа (обычный Label)
@onready var name_label: Label = $NameLabel
# Ссылка на поле, где будет появляться текст реплики по буквам
@onready var text_label: RichTextLabel = $Panel/MarginContainer/HBoxContainer/VBoxContainer/RichTextLabel
# Номер текущей строки диалога. Начинаем с 0
var current_index: int = 0
# Переменная для анимации печатания текста (пока пустая)
var tween: Tween = null
# Правда ли сейчас буквы появляются по одной?
var is_typing: bool = false
# Специальный сигнал, который скажет игре: «Диалог полностью закончился»
signal dialogue_ended
# Сигнал о смене реплики (передает индекс новой реплики)
signal dialogue_line_changed(index: int)
# Отправляет сигнал closed.
signal closed
# Массив для хранения текущих реплик диалога.
# Изначально пустой, заполняется при запуске разговора.
var dialogue_lines: Array = []
# Индекс текущей реплики диалога.
# Нужен, чтобы знать, какую строку показывать игроку сейчас.
# Значение 0 означает первую реплику.
var current_line_index: int = 0


func _ready() -> void:
	# Добавляем в группу для легкого поиска
	add_to_group("DialogueUI")
	visible = false # Скрываем диалог при старте
	process_mode = Node.PROCESS_MODE_ALWAYS
	
	text_label.bbcode_enabled = true
	text_label.scroll_following = true

	text_label.add_theme_color_override("default_color", Color.WHITE) # делаем текст белым, чтобы он точно был виден
	text_label.custom_minimum_size = Vector2(600, 140) # задаём минимальный размер области текста
	text_label.visible = true # убеждаемся, что метка текста отображается
	# text_label.fit_content = true # (опционально) авторазмер по содержимому, если нужно

# Переменная для хранения ссылки на игрока, который начал диалог.
var player: CharacterBody2D = null

# Главная функция, которую ты будем вызывать, когда нужно начать разговор
func start_dialogue(dialog_array: Array[Dictionary], interactor: CharacterBody2D):
	player = interactor # Запоминаем, кто с нами говорит
	dialogues = dialog_array # Запоминаем переданный список реплик
	current_index = 0 # Сбрасываем счётчик на первую строку
	visible = true # Показываем окно диалога на экране
	
	# Замораживаем игру (останавливаем физику и процесс обработки игрока)
	get_tree().paused = true
	
	show_next_line() # Показываем первую реплику
	
# Функция, которая показывает одну строку диалога
# Показывает следующую реплику диалога.
func show_next_line() -> void:
	# Если реплики закончились, закрываем диалог.
	if current_index >= dialogues.size():
		end_dialogue()
		return
	# Берём текущую запись диалога.
	var entry = dialogues[current_index]
	# Сообщаем другим системам, что текущая реплика изменилась.
	dialogue_line_changed.emit(current_index)
	# Обновляем имя говорящего.
	name_label.text = entry["name"]
	# Если для этой реплики указан портрет и узел портрета существует,
	# обновляем изображение.
	if portrait and entry.has("portrait"):
		portrait.texture = entry["portrait"]
	# Берём текст реплики и безопасно превращаем его в строку.
	var line_text := String(entry.get("text", ""))
	# Записываем текст в поле диалога.
	text_label.text = line_text
	# Скрываем все символы, чтобы начать анимацию печати с нуля.
	text_label.visible_characters = 0
	# Считаем количество символов для анимации печати.
	var total_characters: int = int(
		max(text_label.get_total_character_count(), line_text.length())
	)
	# Вычисляем длительность печати:
	# чем длиннее строка, тем дольше она печатается.
	var duration: float = float(
		clamp(float(total_characters) / max(type_speed, 1.0), 0.05, 10.0)
	)
	# Создаём tween для анимации печати текста.
	tween = create_tween()
	# Показываем символы постепенно до конца строки.
	tween.tween_property(text_label, "visible_characters", total_characters, duration)
	# Подключаем обработчик завершения печати.
	tween.finished.connect(_on_tween_finished)
	# Отмечаем, что сейчас идёт печать текста.
	is_typing = true
	
func _on_tween_finished() -> void:
	is_typing = false

# ==================================================
# ЗАКРЫТИЕ ДИАЛОГА
# ==================================================

# Полностью закрывает диалог без прямого обращения к игроку.
func close_window() -> void:
	# Скрываем окно диалога.
	visible = false

# Если у тебя есть переменная активности диалога, сбрасываем её.
func end_dialogue() -> void:
	print("DIALOGUE: вызов закрытия диалога")
	visible = false
	# Очищаем текущие реплики.
	dialogue_lines.clear()
	# Сбрасываем индекс текущей строки.
	current_line_index = 0
	# Снимаем игру с паузы только если больше нет UI, который должен держать паузу.
	var should_pause := false
	if Global != null and "is_smart_watch_open" in Global:
		should_pause = bool(Global.is_smart_watch_open)
	get_tree().paused = should_pause
	# Сообщаем всем, что диалог закрыт.

	print("DIALOGUE: закрытие диалога")
	closed.emit()
	dialogue_ended.emit()
	
func _input(event):
	if not visible: # Если диалог скрыт — ничего не делаем
		return
	
	# Выход из диалога на клавишу Q
	if event is InputEventKey and event.pressed and event.keycode == KEY_Q:
		end_dialogue()
		get_viewport().set_input_as_handled()
		return
	
	# Space (пробел) теперь обрабатывается как ui_accept (далее), 
	# чтобы переключать диалог, а не закрывать его.

	if not event.is_action_pressed("ui_accept"):  # Если нажата НЕ пробел и НЕ Enter
		return                                         

	if is_typing and tween: # Если сейчас идёт печать текста
		tween.kill() # Останавливаем анимацию
		text_label.visible_characters = -1 # Показываем весь текст сразу
		is_typing = false # Больше не печатаем
	else:  # Если текст уже весь виден
		# Проверяем, есть ли следующая фраза
		if current_index + 1 >= dialogues.size():
			# Если это была последняя реплика, то при следующем нажатии закрываем диалог
			end_dialogue()
			return 
		
		# Если фразы еще есть, переходим к следующей
		current_index += 1 
		show_next_line() 
		
	# Говорим Godot: «Мы уже обработали нажатие, не передавай дальше»
	get_viewport().set_input_as_handled()
