extends HSlider

func _ready() -> void:
	min_value = 0.0
	max_value = 100.0
	step = 1.0
	value = float(Global.get_music_volume_percent())
	value_changed.connect(_on_value_changed)

func _on_value_changed(v: float) -> void:
	Global.set_music_volume_percent(v)
