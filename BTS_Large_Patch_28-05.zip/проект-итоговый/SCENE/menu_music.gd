extends AudioStreamPlayer

func _ready() -> void:
	add_to_group("MusicPlayers")
	if stream is AudioStreamMP3:
		(stream as AudioStreamMP3).loop = true
	var cb := Callable(self, "_on_finished")
	if not finished.is_connected(cb):
		finished.connect(cb)
	Global._apply_music_volume_to_group()
	play()

func _on_finished() -> void:
	play()
