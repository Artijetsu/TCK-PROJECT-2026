extends Control

@onready var label = $Panel/Label

func _ready():
	add_to_group("CoinUI")
	update_coins(Global.coins)

func update_coins(amount: int):
	if label:
		label.text = str(amount)
