extends Interactable

# ==================================================
# НАСТРОЙКИ NPC
# ==================================================

# Имя NPC в диалоге.
@export var npc_name: String = "NPC"

# Текст по умолчанию, если список реплик пуст.
@export_multiline var dialogue_text: String = "Привет! Я просто NPC."

# Список реплик NPC.
@export var dialogue_lines: Array[String] = [
	"Привет, путник!",
	"Это деревня новичков.",
	"Здесь можно найти много интересного.",
	"Осторожнее в лесу.",
	"Ты ищешь приключения?",
	"Сходи к выходу внизу, там тебя ждет курьер."
]


# ==================================================
# ССЫЛКИ НА УЗЛЫ
# ==================================================

# Подсказка над NPC.
@onready var hint_label: Label = $HintLabel


# ==================================================
# СОСТОЯНИЕ NPC
# ==================================================

var player_in_zone: CharacterBody2D = null
var dialogue_open: bool = false
var e_was_pressed: bool = false
# Игрок, с которым сейчас открыт диалог.
var interacting_player: CharacterBody2D = null
# Индекс текущей реплики NPC.
var current_dialogue_index: int = 0

# ==================================================
# ПОИСК ИГРОКА В ЗОНЕ NPC
# ==================================================

# Ищем игрока среди всех тел, которые сейчас пересекаются с зоной NPC.
func update_player_in_zone() -> void:
	player_in_zone = null

	var host := get_parent()

	for body in get_overlapping_bodies():
		if not body is CharacterBody2D:
			continue
		# Зона висит на NPC — родительский CharacterBody2D даёт ложное пересечение на всей карте.
		if body == host:
			continue
		player_in_zone = body
		return
# ==================================================
# ИНИЦИАЛИЗАЦИЯ NPC
# ==================================================

# Подготавливаем NPC при загрузке сцены.
func _ready() -> void:
	# Добавляем NPC в группу, чтобы его можно было находить через SceneTree.
	add_to_group("NPC")

	# Включаем отслеживание тел в зоне Area2D.
	# Без этого body_entered и body_exited не будут работать.
	monitoring = true

	# Настраиваем подсказку:
	# задаём текст и сразу скрываем её при старте игры.
	setup_hint_label()

	# Подключаем сигналы входа и выхода игрока в зону,
	# если они ещё не подключены.
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)

	if not body_exited.is_connected(_on_body_exited):
		body_exited.connect(_on_body_exited)


# ==================================================
# НАСТРОЙКА ПОДСКАЗКИ
# ==================================================

# Настраиваем подсказку над NPC.
func setup_hint_label() -> void:
	# Если Label не найден, выходим, чтобы не получить ошибку.
	if hint_label == null:
		return

	# Скрываем подсказку при запуске игры.
	hint_label.visible = false

	hint_label.text = "Нажмите Е"

# ==================================================
# ОБНОВЛЕНИЕ ПОДСКАЗКИ
# ==================================================

# Показывает подсказку только если игрок стоит в зоне
# и диалог сейчас не открыт.
func update_hint_visibility() -> void:
	if hint_label == null:
		return

	hint_label.visible = player_in_zone != null and not dialogue_open
	
# ==================================================
# ОСНОВНОЕ ОБНОВЛЕНИЕ
# ==================================================

func _physics_process(_delta: float) -> void:
	if get_tree().paused:
		return

	update_player_in_zone()
	update_hint_visibility()
	handle_interact_input()


# ==================================================
# ВХОД И ВЫХОД ИЗ ЗОНЫ NPC
# ==================================================

# Когда игрок входит в зону NPC, показываем подсказку.
func _on_body_entered(body: Node) -> void:
	if body == get_parent():
		return
	if body is CharacterBody2D and not dialogue_open:
		if hint_label != null:
			hint_label.visible = true


# Когда игрок выходит из зоны NPC, скрываем подсказку.
func _on_body_exited(body: Node) -> void:
	if body == get_parent():
		return
	if body is CharacterBody2D:
		if hint_label != null:
			hint_label.visible = false


# ==================================================
# УПРАВЛЕНИЕ ПОДСКАЗКОЙ
# ==================================================

# Показывает или скрывает подсказку над NPC.
func set_hint_visible(state: bool) -> void:
	if hint_label != null:
		hint_label.visible = state

# ==================================================
# ОБРАБОТКА КЛАВИШИ E
# ==================================================

func handle_interact_input() -> void:
	var e_pressed := Input.is_physical_key_pressed(KEY_E)

	if player_in_zone != null and not dialogue_open and e_pressed and not e_was_pressed:
		start_npc_dialogue(player_in_zone)

	e_was_pressed = e_pressed


# ==================================================
# ЗАПУСК ДИАЛОГА
# ==================================================

# Открываем диалог с NPC.
func start_npc_dialogue(player: CharacterBody2D) -> void:
	if Global.is_cutscene_playing or Global.is_smart_watch_open:
		return

	var dialogue_ui = get_dialogue_ui()
	if dialogue_ui == null:
		push_error("Не найден UI диалога. Проверь группу DialogueUI.")
		return

	dialogue_open = true
	interacting_player = player

	if player != null and player.has_method("on_interaction_started"):
		player.on_interaction_started()

	var lines := build_dialogue_lines()
	dialogue_ui.start_dialogue(lines, player)

	if dialogue_ui.has_signal("closed"):
		dialogue_ui.closed.connect(_on_dialogue_closed, CONNECT_ONE_SHOT)


# ==================================================
# ПОЛУЧЕНИЕ UI ДИАЛОГА
# ==================================================

# Ищем интерфейс диалогов по группе.
func get_dialogue_ui() -> Node:
	return get_tree().get_first_node_in_group("DialogueUI")


# ==================================================
# СБОРКА ДИАЛОГА
# ==================================================

# Собираем все строки, которые надо показать в этом запуске диалога.
func build_dialogue_lines() -> Array[Dictionary]:
	var lines: Array[Dictionary] = []

	try_give_coin(lines)
	add_current_dialogue_line(lines)

	return lines


# ==================================================
# ВЫДАЧА МОНЕТЫ
# ==================================================

# Один раз выдаём монету и добавляем отдельную реплику.
func try_give_coin(lines: Array[Dictionary]) -> void:
	if Global.npc_coin_given:
		return

	Global.add_coins(4)
	Global.npc_coin_given = true

	lines.append({
		"name": npc_name,
		"text": "Держи монетки! У тебя за шкафом лежали."
	})


# ==================================================
# ОСНОВНАЯ РЕПЛИКА NPC
# ==================================================

# Добавляем текущую реплику NPC.
func add_current_dialogue_line(lines: Array[Dictionary]) -> void:
	if dialogue_lines.is_empty():
		lines.append({
			"name": npc_name,
			"text": dialogue_text
		})
		return

	var line := dialogue_lines[current_dialogue_index]

	check_special_dialogue_events(line)

	lines.append({
		"name": npc_name,
		"text": line
	})

	current_dialogue_index = (current_dialogue_index + 1) % dialogue_lines.size()


# ==================================================
# СПЕЦИАЛЬНЫЕ СОБЫТИЯ
# ==================================================

# Проверяем, есть ли в текущей фразе триггеры.
func check_special_dialogue_events(line: String) -> void:
	if "курьер" in line:
		Global.courier_zone_active = true


# ==================================================
# ЗАКРЫТИЕ ДИАЛОГА
# ==================================================

# Когда диалог закрывается, освобождаем игрока.
func _on_dialogue_closed() -> void:
	dialogue_open = false

	if interacting_player != null and interacting_player.has_method("on_interaction_finished"):
		interacting_player.on_interaction_finished()

	interacting_player = null

	if player_in_zone != null:
		set_hint_visible(true)
	else:
		set_hint_visible(false)


# ==================================================
# ИСЧЕЗНОВЕНИЕ NPC
# ==================================================

# Удаляем NPC с анимацией исчезновения.
func vanish() -> void:
	var parent := get_parent()
	if parent == null:
		return

	parent.process_mode = Node.PROCESS_MODE_ALWAYS

	if parent.has_node("AnimatedSprite2D"):
		var sprite: AnimatedSprite2D = parent.get_node("AnimatedSprite2D")
		await play_vanish_animation(sprite)

	parent.queue_free()


# ==================================================
# АНИМАЦИЯ ИСЧЕЗНОВЕНИЯ
# ==================================================

# Проигрываем анимацию исчезновения.
func play_vanish_animation(sprite: AnimatedSprite2D) -> void:
	var tween := create_tween()

	tween.tween_property(sprite, "scale", Vector2.ZERO, 0.5)
	tween.parallel().tween_property(sprite, "rotation_degrees", 360, 0.5)
	tween.parallel().tween_property(sprite, "modulate:a", 0.0, 0.5)

	await tween.finished
