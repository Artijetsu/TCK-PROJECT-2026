extends Node

var selected_character_path: String = "res://ПЕРСОНАЖИ/character_body_2d.tscn"

# Coin system
var coins: int = 0
var chest_coin_taken: bool = false
var npc_coin_given: bool = false
var smart_watch_intro_completed: bool = false
var is_cutscene_playing: bool = false
var is_smart_watch_open: bool = false
var carry_item_id: String = ""
var carry_item_texture: Texture2D = null
# Флаг, активирующий зону с курьером после разговора с NPC
var courier_zone_active: bool = false
# Флаг, подтверждающий, что диалог с курьером прошел (разблокирует часы)
var courier_dialogue_completed: bool = false

# Данные инвентарей { slot_index: { "id": "...", "texture_path": "..." } }
var wardrobe_data: Dictionary = {}
var chest_data: Dictionary = {}
var hotbar_data: Dictionary = {}
var wardrobe_initialized: bool = false
var chest_initialized: bool = false

var music_volume_percent: int = 100
const MENU_MUSIC_STREAM_PATH := "res://ДРУГОЕ/menu13.mp3"
var _menu_music_player: AudioStreamPlayer = null
var _last_scene_path: String = ""
const WALL_TILE_LAYER_NAMES: Array[String] = ["Wall"]

func _ready() -> void:
	# Регистрация действия key_e программно, если оно отсутствует в InputMap
	if not InputMap.has_action("key_e"):
		InputMap.add_action("key_e")
		var ev = InputEventKey.new()
		ev.keycode = KEY_E
		InputMap.action_add_event("key_e", ev)
		print("Global: Action 'key_e' added manually.")
	
	_load_audio_settings()
	get_tree().connect("node_added", Callable(self, "_on_node_added"))
	_apply_music_volume_to_group()
	_ensure_menu_music_player()
	_update_menu_music_for_current_scene()
	call_deferred("_ensure_wall_colliders_for_current_scene")
	set_process(true)

func _process(_delta: float) -> void:
	_update_menu_music_for_current_scene()

func _ensure_menu_music_player() -> void:
	if _menu_music_player != null and is_instance_valid(_menu_music_player):
		return
	_menu_music_player = AudioStreamPlayer.new()
	_menu_music_player.name = "MenuMusicPlayer"
	_menu_music_player.add_to_group("MusicPlayers")
	if ResourceLoader.exists(MENU_MUSIC_STREAM_PATH):
		_menu_music_player.stream = load(MENU_MUSIC_STREAM_PATH)
		if _menu_music_player.stream is AudioStreamMP3:
			(_menu_music_player.stream as AudioStreamMP3).loop = true
	add_child(_menu_music_player)

func _current_scene_path() -> String:
	var scene := get_tree().current_scene
	if scene == null:
		return ""
	return scene.scene_file_path

func _is_menu_context(scene_path: String) -> bool:
	return scene_path == "res://SCENE/main.tscn" or scene_path == "res://SCENE/main_optimized.tscn" or scene_path == "res://SCENE/settings.tscn" or scene_path == "res://SCENE/scene1.tscn"

func _update_menu_music_for_current_scene() -> void:
	var scene_path := _current_scene_path()
	if scene_path == "":
		return
	if scene_path == _last_scene_path:
		return
	_last_scene_path = scene_path
	_update_menu_music_for_scene(scene_path)

func _update_menu_music_for_scene(scene_path: String) -> void:
	_ensure_menu_music_player()
	if _menu_music_player == null or not is_instance_valid(_menu_music_player):
		return
	if _is_menu_context(scene_path):
		if not _menu_music_player.playing:
			_menu_music_player.play()
	else:
		if _menu_music_player.playing:
			_menu_music_player.stop()

	call_deferred("_ensure_wall_colliders_for_current_scene")


func _ensure_wall_colliders_for_current_scene() -> void:
	var scene := get_tree().current_scene
	if scene == null:
		return

func get_music_volume_percent() -> int:
	return music_volume_percent

func set_music_volume_percent(percent: float) -> void:
	music_volume_percent = int(clamp(percent, 0.0, 100.0))
	_apply_music_volume_to_group()
	_save_audio_settings()

func _on_node_added(node: Node) -> void:
	if node == null:
		return

	if node.is_in_group("MusicPlayers"):
		var db := _music_volume_db()
		if node is AudioStreamPlayer:
			(node as AudioStreamPlayer).volume_db = db
		elif node is AudioStreamPlayer2D:
			(node as AudioStreamPlayer2D).volume_db = db
		elif node is AudioStreamPlayer3D:
			(node as AudioStreamPlayer3D).volume_db = db

	if node is TileMapLayer and WALL_TILE_LAYER_NAMES.has(node.name):
		call_deferred("_ensure_wall_colliders_for_tile_layer", node)


func _ensure_wall_colliders_for_tile_layer(layer: TileMapLayer) -> void:
	if layer == null or not is_instance_valid(layer):
		return

	if layer.get_node_or_null("_GeneratedColliders") != null:
		return

	var tile_set: TileSet = layer.tile_set
	if tile_set == null:
		return

	var tile_size := Vector2(tile_set.tile_size)
	if tile_size == Vector2.ZERO:
		return

	var container := Node2D.new()
	container.name = "_GeneratedColliders"
	layer.add_child(container)

	var idx := 0
	for cell in layer.get_used_cells():
		var body := StaticBody2D.new()
		body.name = "WallCollider%d" % idx
		idx += 1
		body.collision_layer = 1
		body.collision_mask = 0

		var shape_node := CollisionShape2D.new()
		var rect := RectangleShape2D.new()
		rect.size = tile_size
		shape_node.shape = rect
		body.add_child(shape_node)

		body.position = layer.map_to_local(cell) + tile_size * 0.5
		container.add_child(body)

func _music_volume_db() -> float:
	if music_volume_percent <= 0:
		return -80.0
	return linear_to_db(float(music_volume_percent) / 100.0)

func _apply_music_volume_to_group() -> void:
	var db := _music_volume_db()
	for node in get_tree().get_nodes_in_group("MusicPlayers"):
		if node is AudioStreamPlayer:
			(node as AudioStreamPlayer).volume_db = db
		elif node is AudioStreamPlayer2D:
			(node as AudioStreamPlayer2D).volume_db = db
		elif node is AudioStreamPlayer3D:
			(node as AudioStreamPlayer3D).volume_db = db

func _save_audio_settings() -> void:
	var cfg := ConfigFile.new()
	var err := cfg.load("user://settings.cfg")
	if err != OK:
		cfg = ConfigFile.new()
	cfg.set_value("audio", "music_volume_percent", music_volume_percent)
	cfg.save("user://settings.cfg")

func _load_audio_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load("user://settings.cfg") == OK:
		music_volume_percent = int(cfg.get_value("audio", "music_volume_percent", music_volume_percent))
	music_volume_percent = int(clamp(float(music_volume_percent), 0.0, 100.0))

func add_coins(amount: int) -> void:
	coins += amount
	# Update UI if it exists
	var coin_ui = get_tree().get_first_node_in_group("CoinUI")
	if coin_ui and coin_ui.has_method("update_coins"):
		coin_ui.update_coins(coins)

func spend_coins(amount: int) -> bool:
	if coins >= amount:
		coins -= amount
		var coin_ui = get_tree().get_first_node_in_group("CoinUI")
		if coin_ui and coin_ui.has_method("update_coins"):
			coin_ui.update_coins(coins)
		return true
	return false

func init_wardrobe_data() -> void:
	if wardrobe_initialized:
		return
	wardrobe_initialized = true
	
	# Разбрасываем 5 монет по случайным слотам (для простоты - фиксированным, чтобы не искать пустые)
	# Слоты: 3, 12, 25, 40, 50 (индексы с 0: 2, 11, 24, 39, 49)
	var coin_slots = [2, 11, 24, 39, 49]
	for idx in coin_slots:
		wardrobe_data[idx] = {
			"id": "coin",
			"texture_path": "res://IMG/монетка.png"
		}
	
	# Добавляем одежду (Шляпа) в слот 1 (индекс 1)
	wardrobe_data[1] = {
		"id": "clothes",
		"texture_path": "res://ДРУГОЕ/Mana Seed Farmer Sprite Free Sample/farmer base sheets/14head/fbas_14head_cowboyhat_00d.png"
	}

func init_chest_data() -> void:
	if chest_initialized:
		return
	chest_initialized = true
	
	# Если монета еще не взята по старой логике
	if not chest_coin_taken:
		chest_data[0] = {
			"id": "coin",
			"texture_path": "res://IMG/монетка.png"
		}
	# Можно добавить ноутбук, если он нужен
	# chest_data[1] = { "id": "notebook", "texture_path": "res://IMG/notebook.png" }

func set_inventory_item(container: String, slot_idx: int, id: String, tex_path: String) -> void:
	var data: Dictionary
	if container == "Wardrobe":
		data = wardrobe_data
	elif container == "Chest":
		data = chest_data
	elif container == "Hotbar":
		data = hotbar_data
	else:
		return
		
	if id == "":
		data.erase(slot_idx)
	else:
		data[slot_idx] = {
			"id": id,
			"texture_path": tex_path
		}
