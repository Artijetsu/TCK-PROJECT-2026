extends Area2D


# ==================================================
# ССЫЛКИ НА УЗЛЫ
# ==================================================

# Подсказка над сундуком.
@onready var hint_label: Label = $HintLabel


# ==================================================
# НАСТРОЙКИ
# ==================================================

# Текст подсказки.
@export var hint_text: String = "Нажмите E"


# ==================================================
# СОСТОЯНИЕ
# ==================================================

# Игрок, который сейчас стоит в зоне сундука.
var player_in_zone: CharacterBody2D = null

# Игрок, который открыл сундук.
var interacting_player: CharacterBody2D = null

# Открыт ли сейчас интерфейс сундука.
var ui_open: bool = false

# Нужно для отслеживания одиночного нажатия E.
var e_was_pressed: bool = false


# ==================================================
# ИНИЦИАЛИЗАЦИЯ
# ==================================================

func _ready() -> void:
	# Включаем отслеживание тел в зоне.
	monitoring = true

	# Настраиваем подсказку.
	if hint_label != null:
		hint_label.visible = false
		hint_label.text = hint_text

	# Подключаем сигналы входа и выхода игрока.
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)


# ==================================================
# ОБНОВЛЕНИЕ
# ==================================================

func _process(_delta: float) -> void:
	# Если игра на паузе, ничего не делаем.
	if get_tree().paused:
		return

	# Проверяем текущее состояние клавиши E.
	var e_pressed := Input.is_physical_key_pressed(KEY_E)

	# Если игрок в зоне, интерфейс ещё закрыт,
	# и E нажата только что — открываем сундук.
	if player_in_zone != null and not ui_open and e_pressed and not e_was_pressed:
		open_chest(player_in_zone)

	# Запоминаем состояние клавиши на этот кадр.
	e_was_pressed = e_pressed


# ==================================================
# ВХОД И ВЫХОД ИЗ ЗОНЫ
# ==================================================

func _on_body_entered(body: Node) -> void:
	# Если в зону вошёл игрок, запоминаем его.
	if body is CharacterBody2D:
		player_in_zone = body

		# Показываем подсказку, если интерфейс не открыт.
		if hint_label != null and not ui_open:
			hint_label.visible = true

		print("Игрок вошёл в зону сундука")


func _on_body_exited(body: Node) -> void:
	# Если вышел тот же игрок, который был в зоне, очищаем ссылку.
	if body == player_in_zone:
		player_in_zone = null

	# Если интерфейс не открыт, скрываем подсказку.
	if hint_label != null and not ui_open:
		hint_label.visible = false

	print("Игрок вышел из зоны сундука")


# ==================================================
# ОТКРЫТИЕ СУНДУКА
# ==================================================

func open_chest(player: CharacterBody2D) -> void:
	# Сохраняем состояние открытия.
	ui_open = true
	interacting_player = player

	# Скрываем подсказку.
	if hint_label != null:
		hint_label.visible = false

	# Блокируем игрока, если у него есть нужный метод.
	if player != null and player.has_method("on_interaction_started"):
		player.on_interaction_started()

	# Ищем уже существующий интерфейс сундука.
	var ui = get_tree().get_first_node_in_group("ChestUI")

	# Если интерфейс уже есть, просто открываем его.
	if ui != null:
		if ui.has_method("open"):
			ui.open()

		if ui.has_signal("closed"):
			ui.closed.connect(_on_ui_closed, CONNECT_ONE_SHOT)

		print("Сундук открыт")
		return

	# Загружаем сцену интерфейса сундука.
	var packed_scene = load("res://SCENE/chest_ui.tscn")

	# Если сцену загрузить не удалось, откатываем открытие.
	if packed_scene == null:
		push_error("Не удалось загрузить res://SCENE/chest_ui.tscn")
		close_chest()
		return

	# Создаём экземпляр интерфейса.
	var instance = packed_scene.instantiate()

	# Добавляем его в текущую сцену.
	get_tree().current_scene.add_child(instance)

	# Ищем основной управляющий узел интерфейса.
	var control = instance.get_node_or_null("CanvasLayer/Control")

	# Если узел не найден, откатываем открытие.
	if control == null:
		push_error("Не найден узел CanvasLayer/Control в chest_ui.tscn")
		close_chest()
		return

	# Открываем интерфейс.
	if control.has_method("open"):
		control.open()

	# Подключаем закрытие интерфейса.
	if control.has_signal("closed"):
		control.closed.connect(_on_ui_closed, CONNECT_ONE_SHOT)

	print("Сундук открыт")


# ==================================================
# ЗАКРЫТИЕ СУНДУКА
# ==================================================

func close_chest() -> void:
	# Помечаем, что интерфейс больше не открыт.
	ui_open = false

	# Освобождаем игрока.
	if interacting_player != null and interacting_player.has_method("on_interaction_finished"):
		interacting_player.on_interaction_finished()

	# Очищаем ссылку на игрока.
	interacting_player = null

	# Если игрок всё ещё стоит в зоне, снова показываем подсказку.
	if hint_label != null:
		hint_label.visible = player_in_zone != null

	print("Сундук закрыт")


# ==================================================
# ЗАКРЫТИЕ ЧЕРЕЗ UI
# ==================================================

func _on_ui_closed() -> void:
	# При закрытии UI закрываем сундук.
	close_chest()
