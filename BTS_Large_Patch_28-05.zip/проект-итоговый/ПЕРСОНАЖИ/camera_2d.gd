extends Camera2D

# --- НАСТРОЙКИ УРОВНЯ (Измените их в Инспекторе или оставьте как есть) ---
# Я вписал сюда ваши значения, чтобы они точно сработали по умолчанию.
@export_group("Границы Уровня")
@export var level_left: int = 3
@export var level_top: int = -633
@export var level_right: int = 1918
@export var level_bottom: int = 1277

@export_group("Настройки Камеры")
# 1.0 = показывать уровень впритык к краям
# 0.9 = оставить небольшие черные полосы (отступы)
@export var margin_scale: float = 1.0

func _ready() -> void:
	# 1. Отвязываем камеру от игрока, чтобы она стояла на месте
	top_level = true
	
	# 2. Применяем лимиты из переменных скрипта в свойства камеры
	# Это гарантирует, что используются именно эти числа
	limit_left = level_left
	limit_top = level_top
	limit_right = level_right
	limit_bottom = level_bottom
	
	# 3. Активируем камеру
	enabled = true
	make_current()
	
	# 4. Отключаем сглаживание (для статичной камеры оно не нужно)
	position_smoothing_enabled = false
	drag_horizontal_enabled = false
	drag_vertical_enabled = false
	
	# Для отладки: пишем в консоль (внизу редактора), какие лимиты применились
	print("--- КАМЕРА АКТИВИРОВАНА ---")
	print("Лимиты: Слева=", limit_left, " Справа=", limit_right, " Верх=", limit_top, " Низ=", limit_bottom)
	
	# 5. Настраиваем зум
	fit_camera_to_limits()

func _process(delta: float) -> void:
	# Постоянно следим за размером окна
	fit_camera_to_limits()

func fit_camera_to_limits() -> void:
	# Считаем размеры мира
	var world_width = limit_right - limit_left
	var world_height = limit_bottom - limit_top
	
	# Если вдруг размеры нулевые или отрицательные (защита от ошибок)
	if world_width <= 10: world_width = 100
	if world_height <= 10: world_height = 100

	# Получаем размер окна игрока
	var screen_size = get_viewport_rect().size
	
	# Считаем зум по ширине и высоте
	var zoom_x = screen_size.x / float(world_width)
	var zoom_y = screen_size.y / float(world_height)
	
	# Выбираем тот, который меньше (чтобы всё влезло)
	var final_zoom = min(zoom_x, zoom_y) * margin_scale
	
	# Применяем зум
	zoom = Vector2(final_zoom, final_zoom)
	
	# Ставим камеру в центр
	var center_x = (limit_left + limit_right) / 2.0
	var center_y = (limit_top + limit_bottom) / 2.0
	
	global_position = Vector2(center_x, center_y)
