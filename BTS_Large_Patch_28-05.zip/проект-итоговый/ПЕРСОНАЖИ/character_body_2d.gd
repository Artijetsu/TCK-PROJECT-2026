extends CharacterBody2D


# ==================================================
# НАСТРОЙКИ ДВИЖЕНИЯ
# ==================================================

# Скорость ходьбы.
@export var walk_speed: float = 210.0

# Скорость бега.
@export var run_speed: float = 400.0

# Скорость разгона.
@export var acceleration: float = 1500.0

# Скорость торможения.
@export var friction: float = 1500.0


# ==================================================
# ССЫЛКИ НА УЗЛЫ
# ==================================================

# Ссылка на анимированный спрайт игрока.
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D


# ==================================================
# СОСТОЯНИЕ
# ==================================================

# Флаг, показывающий, занят ли игрок взаимодействием.
var is_interacting: bool = false


# ==================================================
# ИНИЦИАЛИЗАЦИЯ
# ==================================================

func _ready() -> void:
	# Для пиксель-арта отключаем размытие.
	if animated_sprite != null:
		animated_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST


# ==================================================
# ОСНОВНОЙ ЦИКЛ
# ==================================================

func _physics_process(delta: float) -> void:
	# Если игра на паузе, выходим.
	if get_tree().paused:
		return

	# Если игрок взаимодействует, блокируем движение.
	if is_interacting:
		velocity = Vector2.ZERO
		update_animation(Vector2.ZERO)
		move_and_slide()
		return

	# Получаем направление движения.
	var direction := get_move_direction()

	# Обновляем скорость.
	update_movement(direction, delta)

	# Обновляем анимацию.
	update_animation(direction)

	# Двигаем игрока.
	move_and_slide()


# ==================================================
# НАПРАВЛЕНИЕ ДВИЖЕНИЯ
# ==================================================

func get_move_direction() -> Vector2:
	# Начальный вектор.
	var direction := Vector2.ZERO

	# Вверх.
	if Input.is_physical_key_pressed(KEY_W):
		direction.y -= 1

	# Вниз.
	if Input.is_physical_key_pressed(KEY_S):
		direction.y += 1

	# Влево.
	if Input.is_physical_key_pressed(KEY_A):
		direction.x -= 1

	# Вправо.
	if Input.is_physical_key_pressed(KEY_D):
		direction.x += 1

	# Нормализуем движение.
	return direction.normalized()


# ==================================================
# ДВИЖЕНИЕ
# ==================================================

func update_movement(direction: Vector2, delta: float) -> void:
	# По умолчанию ходим.
	var current_speed := walk_speed

	# Shift включает бег.
	if Input.is_physical_key_pressed(KEY_SHIFT):
		current_speed = run_speed

	# Целевая скорость.
	var target_velocity := direction * current_speed

	# Разгон или торможение.
	if direction != Vector2.ZERO:
		velocity = velocity.move_toward(target_velocity, acceleration * delta)
	else:
		velocity = velocity.move_toward(Vector2.ZERO, friction * delta)


# ==================================================
# СОСТОЯНИЕ ВЗАИМОДЕЙСТВИЯ
# ==================================================

func on_interaction_started() -> void:
	# Блокируем игрока.
	is_interacting = true
	velocity = Vector2.ZERO


func on_interaction_finished() -> void:
	# Освобождаем игрока.
	is_interacting = false


# ==================================================
# АНИМАЦИЯ
# ==================================================

func update_animation(direction: Vector2) -> void:
	# Если спрайта нет, выходим.
	if animated_sprite == null:
		return

	# Если игрок стоит, останавливаем анимацию.
	if direction == Vector2.ZERO:
		animated_sprite.stop()
		animated_sprite.frame = 0
		return

	# Горизонтальная анимация.
	if abs(direction.x) > abs(direction.y):
		animated_sprite.play("right")
		animated_sprite.flip_h = direction.x < 0
		return

	# Вертикальная анимация.
	animated_sprite.flip_h = false

	if direction.y > 0:
		animated_sprite.play("down")
	else:
		animated_sprite.play("top")
